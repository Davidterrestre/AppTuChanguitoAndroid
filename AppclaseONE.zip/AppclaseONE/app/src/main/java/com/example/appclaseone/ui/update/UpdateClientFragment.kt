package com.example.appclaseone.ui.update

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import com.example.appclaseone.R
import com.example.appclaseone.databinding.FragmentUpdateClientBinding
import com.example.appclaseone.model.Client
import com.example.appclaseone.viewmodel.ClientViewModel


class UpdateClientFragment : Fragment(), MenuProvider {

    private lateinit var binding: FragmentUpdateClientBinding
    private var client: Client? = null

    private val clientViewModel by viewModels<ClientViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentUpdateClientBinding.inflate(inflater, container, false)

        client = arguments?.getSerializable("client") as Client

        binding.etRazonSocial.setText(client!!.razonSocial)
        binding.etCuit.setText(client!!.cuit)
        binding.etEmail.setText(client!!.email)
        binding.etTelefono.setText(client!!.telefono.toString())
        binding.etDireccion.setText(client!!.direccion)



        binding.btnUpdate.setOnClickListener {
            validateFields(client!!)
        }


        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        /*menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.delete_menu, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when(menuItem.itemId) {
                    R.menu.delete_menu -> {
                        deleteUser(user)
                        true
                    }

                    else -> {
                        false
                    }
                }
            }
        })*/


        return binding.root
    }


    private fun deleteClient(client: Client) {
        val dialog = AlertDialog.Builder(requireContext())

        dialog.setNegativeButton("No") { _, _ ->
            //return@setNegativeButton
        }

        dialog.setPositiveButton("Yes") { _,_ ->
            clientViewModel.deleteClient(client = client)
            Toast.makeText(requireContext(), "Cliente eliminado!", Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.action_updateClientFragment_to_listFragment)
        }

        dialog.setTitle("¿Desea eliminar?")
        dialog.setMessage("Esta seguro que desea eliminar ha ${client.razonSocial} con el cuit ${client.cuit}")

        dialog.create().show()
    }


    private fun validateFields(client: Client) {
        val razonSocial = binding.etRazonSocial.text.toString()
        val cuit = binding.etCuit.text.toString()
        val email = binding.etEmail.text.toString()
        val telefono = binding.etTelefono.text.toString()
        val direccion = binding.etDireccion.text.toString()


        if (razonSocial.isNotEmpty() && cuit.isNotEmpty() && email.isNotEmpty() && direccion.isNotEmpty()) {

            val client2 = client.copy( razonSocial = razonSocial, cuit = cuit, email = email,direccion = direccion, telefono = telefono.toInt())

            clientViewModel.updateClient(client = client2)
            findNavController().navigate(R.id.action_updateClientFragment_to_listFragment)
        }
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.delete_menu, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when(menuItem.itemId) {
            R.id.menu_delete -> {
                deleteClient(client = client!!)
                true
            }

            else -> {
                false
            }
        }
    }


}