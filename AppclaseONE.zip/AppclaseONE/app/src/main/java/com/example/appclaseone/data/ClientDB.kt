package com.example.appclaseone.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.appclaseone.AppClassOne
import com.example.appclaseone.model.Client
import com.example.appclaseone.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

@Database(entities = [Client::class], version = 1, exportSchema = false)
abstract class ClientDB : RoomDatabase() {

    abstract fun clientDao(): ClientDao

    companion object {
        @Volatile
        private var INSTANCE: ClientDB? = null

        fun getDatabase(): ClientDB {
            val tempInstance = INSTANCE

            if(tempInstance != null) {
                return tempInstance
            }

            synchronized(this) {
                val instance = Room.databaseBuilder(
                    AppClassOne.instance.applicationContext,
                    ClientDB::class.java,
                    Constants.appDBName
                )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                return instance
            }
        }

    }

}