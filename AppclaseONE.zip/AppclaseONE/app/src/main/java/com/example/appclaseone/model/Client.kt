package com.example.appclaseone.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable


@Entity(tableName = "client_table")
data class Client(
    @PrimaryKey(autoGenerate = true)
    val id: Int,

    val razonSocial: String,
    val cuit : String,
    val telefono : Int,
    val email: String,
    val direccion : String

) : Serializable