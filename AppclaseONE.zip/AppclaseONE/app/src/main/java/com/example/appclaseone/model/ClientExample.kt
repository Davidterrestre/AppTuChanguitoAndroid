package com.example.appclaseone.model



data class ClientExample(
    val id: Int,
    val razonSocial: String,
    val cuit : String,
    val telefono : Int,
    val email: String,
    val direccion : String
)