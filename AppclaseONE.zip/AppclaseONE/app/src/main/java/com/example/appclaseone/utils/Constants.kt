package com.example.appclaseone.utils



object Constants {

    val appDBName = "client_database"
}