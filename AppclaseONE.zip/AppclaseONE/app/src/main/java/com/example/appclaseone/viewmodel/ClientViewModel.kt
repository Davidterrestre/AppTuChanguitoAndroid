package com.example.appclaseone.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.appclaseone.model.Client
import com.example.appclaseone.repository.ClientRepository
import kotlinx.coroutines.launch


class ClientViewModel : ViewModel() {

    private val clientRepository = ClientRepository()

    val readAllData: LiveData<List<Client>> = clientRepository.readAllData


    fun insertClient(client: Client) {
        viewModelScope.launch {
            clientRepository.insertClient(client = client)
        }
    }


    fun updateClient(client: Client) {
        viewModelScope.launch {
            clientRepository.updateClient(client = client)
        }
    }

    fun deleteClient(client: Client) {
        viewModelScope.launch {
            clientRepository.deleteClient(client = client)
        }
    }

    fun deleteAllClient() {
        viewModelScope.launch {
            clientRepository.deleteAllClient()
        }
    }

}