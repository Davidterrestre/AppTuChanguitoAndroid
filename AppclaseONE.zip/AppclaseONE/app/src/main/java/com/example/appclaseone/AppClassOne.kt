package com.example.appclaseone

import android.app.Application


class AppClassOne: Application() {

    companion object {
        lateinit var instance: AppClassOne
    }


    override fun onCreate() {
        super.onCreate()
        instance = this
    }

}