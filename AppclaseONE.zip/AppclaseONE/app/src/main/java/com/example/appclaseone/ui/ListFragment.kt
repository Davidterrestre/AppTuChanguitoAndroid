package com.example.appclaseone.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.core.view.MenuHost
import androidx.fragment.app.Fragment
import androidx.core.view.MenuProvider
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.appclaseone.R
import com.example.appclaseone.databinding.FragmentListBinding
import com.example.appclaseone.model.Client
import com.example.appclaseone.model.ClientExample
import com.example.appclaseone.viewmodel.ClientViewModel


class ListFragment : Fragment(), MenuProvider {

    private lateinit var binding: FragmentListBinding
    private val clientViewModel by viewModels<ClientViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentListBinding.inflate(inflater, container, false)


        val adapter = ListAdapter()
        binding.listRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.listRecyclerView.adapter = adapter


        // Linea divisoria
        val divider = DividerItemDecoration(requireContext(), LinearLayoutManager(requireContext()).orientation)
        binding.listRecyclerView.addItemDecoration(divider)


        binding.btnAddClient.setOnClickListener {
            findNavController().navigate(R.id.action_listFragment_to_addClientFragment)
        }

        clientViewModel.readAllData.observe(viewLifecycleOwner) { clients ->
            adapter.setData(clients = clients)
        }


        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    private fun deleteAllClient() {
        val dialog = AlertDialog.Builder(requireContext())

        dialog.setNegativeButton("No") { _, _ ->
            //return@setNegativeButton
        }

        dialog.setPositiveButton("Yes") { _,_ ->
            clientViewModel.deleteAllClient()
        }

        dialog.setTitle("¿Desea eliminar?")
        dialog.setMessage("Esta seguro que desea eliminar todos los clientes")

        dialog.create().show()
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.delete_menu, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when(menuItem.itemId) {
            R.id.menu_delete -> {
                deleteAllClient()
                true
            }

            else -> {
                false
            }
        }
    }

}