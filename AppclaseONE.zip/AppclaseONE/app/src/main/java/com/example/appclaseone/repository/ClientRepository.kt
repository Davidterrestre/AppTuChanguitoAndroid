package com.example.appclaseone.repository

import androidx.lifecycle.LiveData
import com.example.appclaseone.data.ClientDB
import com.example.appclaseone.model.Client


class ClientRepository {



    private val clientDao = ClientDB.getDatabase().clientDao()

    val readAllData: LiveData<List<Client>> = clientDao.readAllData()


    suspend fun insertClient(client: Client) {
        clientDao.insertClient(client = client)
    }


    suspend fun updateClient(client: Client) {
        clientDao.updateClient(client = client)
    }

    suspend fun deleteClient(client: Client) {
        clientDao.deleteClient(client = client)
    }

    suspend fun deleteAllClient() {
        clientDao.deleteAll()
    }

}