package com.example.appclaseone.ui.add

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.appclaseone.R
import com.example.appclaseone.databinding.FragmentAddClientBinding
import com.example.appclaseone.model.Client
import com.example.appclaseone.viewmodel.ClientViewModel


class AddClientFragment : Fragment() {

    private lateinit var binding: FragmentAddClientBinding
    private val clientViewModel by viewModels<ClientViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddClientBinding.inflate(inflater, container, false)


        binding.btnAdd.setOnClickListener {
            insertDatatoDataBase()
        }


        return binding.root
    }

    private fun inputCheck(razonSocial: String, cuit: String,email: String,direccion : String): Boolean {
        return if (razonSocial.isNotEmpty() && cuit.isNotEmpty() && email.isNotEmpty() && direccion.isNotEmpty()) {
            true
        } else {
            false
        }
    }

    private fun insertDatatoDataBase() {
        val razonSocial = binding.etRazonSocial.text.toString()
        val cuit = binding.etCuit.text.toString()
        val email = binding.etEmail.text.toString()
        val telefono = binding.etTelefono.text.toString()
        val direccion = binding.etDireccion.text.toString()

        if (inputCheck(razonSocial, cuit, email, direccion)) {

            // Crea el objeto del usuario
            val client = Client(id = 0, razonSocial = razonSocial, cuit = cuit, email = email,direccion = direccion, telefono = telefono.toInt())

            // se lo pasa al viewmodel para agregalo a la db
            clientViewModel.insertClient(client = client)

            Toast.makeText(requireContext(), "Agregado!", Toast.LENGTH_SHORT).show()

            // navegamos al listado
            findNavController().navigate(R.id.action_addClientFragment_to_listFragment)
            Log.d("AddClientFrag", "cliente creado! $client")

        } else {
            Toast.makeText(requireContext(), "Complete todos los datos!", Toast.LENGTH_SHORT).show()
        }
    }


}