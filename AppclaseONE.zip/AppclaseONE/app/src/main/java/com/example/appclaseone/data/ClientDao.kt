package com.example.appclaseone.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.appclaseone.model.Client

@Dao
interface ClientDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertClient(client: Client)

    @Query("SELECT * FROM client_table ORDER BY id ASC")
    fun readAllData(): LiveData<List<Client>>

    @Update
    suspend fun updateClient(client: Client)

    @Delete
    suspend fun deleteClient(client: Client)

    @Query("DELETE FROM client_table")
    suspend fun deleteAll()

}