package com.example.appclaseone.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.appclaseone.R
import com.example.appclaseone.databinding.ItemListRecyclerviewBinding
import com.example.appclaseone.model.Client
import com.example.appclaseone.model.ClientExample


class ListAdapter() : RecyclerView.Adapter<ListAdapter.ListViewHolder>() {

    private var clientList = emptyList<Client>()
    var context: Context? = null


    inner class ListViewHolder(private val binding: ItemListRecyclerviewBinding): RecyclerView.ViewHolder(binding.root) {

        fun bind(client: Client) {
            binding.tvId.text = client.id.toString()
            binding.tvRazonSocial.text = client.razonSocial
            binding.tvCuit.text = client.cuit
            binding.tvEmail.text = client.email
            binding.tvTelefono.text = client.email.toString()
            binding.tvDireccion.text = client.direccion


            binding.root.setOnClickListener {
                val bundle = Bundle()
                bundle.putSerializable("client", client)
                itemView.findNavController().navigate(R.id.action_listFragment_to_updateClientFragment, bundle)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        context = parent.context
        val binding = ItemListRecyclerviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding = binding)
    }


    override fun getItemCount(): Int {
        return clientList.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {

        val client = clientList.get(position)
        holder.bind(client)

    }


    @SuppressLint("NotifyDataSetChanged")
    fun setData(clients: List<Client>) {
        this.clientList = clients
        notifyDataSetChanged()
    }

}